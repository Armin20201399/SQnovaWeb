import React, { useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { ProtocolDeepDive } from './components/ProtocolDeepDive';
import { LiveGamingPingSimulator } from './components/LiveGamingPingSimulator';
import { ServerStatusSection } from './components/ServerStatusSection';
import { GameNetPartnershipSection } from './components/GameNetPartnershipSection';
import { FreeTrialDedicatedSection } from './components/FreeTrialDedicatedSection';
import { ServicePackagesSection } from './components/ServicePackagesSection';
import { ClientAppsDownload } from './components/ClientAppsDownload';
import { FaqSection } from './components/FaqSection';
import { PrivacyAndTermsSection } from './components/PrivacyAndTermsSection';
import { Footer } from './components/Footer';
import { BinaryBackground } from './components/BinaryBackground';

export default function App() {
  const handleScrollToSection = (sectionId: string) => {
    const cleanId = sectionId.replace('#', '').replace('/', '');
    const el = document.getElementById(cleanId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      // Update hash in URL without full reload
      window.history.replaceState(null, '', `#${cleanId}`);
    }
  };

  useEffect(() => {
    // Handle initial hash or path navigation (e.g., #privacy, /privacy, #status, #terms)
    const hash = window.location.hash.replace('#', '');
    const pathname = window.location.pathname.replace('/', '');
    const target = hash || pathname;

    if (target) {
      setTimeout(() => {
        const el = document.getElementById(target);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth' });
        }
      }, 300);
    }
  }, []);

  return (
    <div className="min-h-screen text-slate-100 font-['Vazirmatn',sans-serif] selection:bg-pink-500/30 selection:text-pink-200 overflow-x-hidden rtl relative">
      <BinaryBackground />
      
      {/* Top Navbar */}
      <Navbar onScrollToSection={handleScrollToSection} />

      {/* Main Landing Sections */}
      <main>
        {/* 1. Hero Section with 0% Packet Loss & Europe/Iran MikroTik Focus */}
        <HeroSection onScrollToSection={handleScrollToSection} />

        {/* 2. Protocol Deep Dive (Hysteria 2 UDP, TCP Reality, xHTTP, mKCP) */}
        <ProtocolDeepDive onScrollToSection={handleScrollToSection} />

        {/* 3. Live Gaming Ping & Jitter Simulator with Europe Core */}
        <LiveGamingPingSimulator onScrollToSection={handleScrollToSection} />

        {/* 4. Real-time Server Nodes Status (Sweden, Netherlands, Germany, Turkey, Iran) */}
        <ServerStatusSection onScrollToSection={handleScrollToSection} />

        {/* 5. GameNet & Esports Club Partnership Plan */}
        <GameNetPartnershipSection />

        {/* 6. Prominent Dedicated 24-Hour Free Trial Section */}
        <FreeTrialDedicatedSection onScrollToSection={handleScrollToSection} />

        {/* 7. Service Packages & Universal Smart Sub */}
        <ServicePackagesSection onScrollToSection={handleScrollToSection} />

        {/* 8. Multi-Platform Client Apps Download */}
        <ClientAppsDownload />

        {/* 9. Frequently Asked Questions Accordion */}
        <FaqSection onScrollToSection={handleScrollToSection} />

        {/* 10. Privacy Policy & Terms of Service */}
        <PrivacyAndTermsSection onScrollToSection={handleScrollToSection} />
      </main>

      {/* Footer */}
      <Footer onScrollToSection={handleScrollToSection} />

    </div>
  );
}
