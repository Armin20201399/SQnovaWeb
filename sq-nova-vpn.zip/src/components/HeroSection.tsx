import React from 'react';
import { 
  Flame, 
  Sparkles, 
  Gamepad2, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  ArrowLeft, 
  Radio, 
  Globe2,
  Server,
  Layers,
  Network,
  Cpu,
  Activity
} from 'lucide-react';
import { FlameLogo } from './FlameLogo';
import { BinaryText } from './BinaryText';

interface HeroSectionProps {
  onScrollToSection: (sectionId: string) => void;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onScrollToSection
}) => {
  const [zeroVal, setZeroVal] = React.useState('0.0%');
  const [uptimeVal, setUptimeVal] = React.useState('99.99%');
  const [hubPing, setHubPing] = React.useState(58);
  const [euServers, setEuServers] = React.useState([
    { id: 'hetzner', name: 'هتزنر آلمان', ping: 85 },
    { id: 'apex', name: 'ایپکس هلند', ping: 95 },
    { id: 'sweden', name: 'ایپکس سوئد', ping: 90 },
  ]);
  const [iranServers, setIranServers] = React.useState([
    { id: 'asiatech', name: 'آسیاتک', ping: 12 },
    { id: 'shatel', name: 'شاتل', ping: 15 },
    { id: 'hayweb', name: 'های وب', ping: 19 },
  ]);

  React.useEffect(() => {
    const interval = setInterval(() => {
      setEuServers(prev => prev.map(r => {
        const basePing = r.id === 'hetzner' ? 85 : r.id === 'apex' ? 95 : 90;
        const delta = Math.floor(Math.random() * 9) - 4; // -4 to +4
        return { ...r, ping: basePing + delta };
      }));
      setIranServers(prev => prev.map(r => {
        const delta = Math.floor(Math.random() * 7) - 3;
        let newPing = r.ping + delta;
        if (newPing < 8) newPing = 8;
        if (newPing > 40) newPing = 40;
        return { ...r, ping: newPing };
      }));
      setHubPing(prev => {
        const delta = Math.floor(Math.random() * 5) - 2;
        let newPing = prev + delta;
        if (newPing < 54) newPing = 54;
        if (newPing > 64) newPing = 64;
        return newPing;
      });
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  React.useEffect(() => {
    let timeoutId: NodeJS.Timeout;

    const scheduleNext = () => {
      const delay = Math.floor(Math.random() * 500) + 300; // 300ms to 800ms random interval
      timeoutId = setTimeout(() => {
        // Randomize packet loss value with fixed width (0.0%, 0.1%, 1.0%)
        const possibleLoss = ['0.0%', '0.1%', '0.0%', '1.0%', '0.0%'];
        setZeroVal(possibleLoss[Math.floor(Math.random() * possibleLoss.length)]);

        // Randomize uptime value between 99.95% and 99.99% (never 100%)
        const possibleUptime = ['99.99%', '99.98%', '99.97%', '99.96%', '99.95%'];
        setUptimeVal(possibleUptime[Math.floor(Math.random() * possibleUptime.length)]);

        scheduleNext();
      }, delay);
    };

    scheduleNext();
    return () => clearTimeout(timeoutId);
  }, []);

  return (
    <section 
      id="hero-section"
      className="relative min-h-[92vh] flex items-center justify-center pt-28 pb-16 overflow-hidden bg-cyber-grid"
    >
      {/* Ambient Atmospheric Lighting Orbs */}
      <div className="absolute top-1/4 -right-20 w-96 h-96 bg-purple-900/20 rounded-full blur-[120px] pointer-events-none animate-pulse"></div>
      <div className="absolute top-1/3 -left-20 w-96 h-96 bg-orange-600/15 rounded-full blur-[120px] pointer-events-none animate-pulse" style={{ animationDuration: '4s' }}></div>
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 w-[700px] h-80 bg-pink-900/15 rounded-full blur-[140px] pointer-events-none"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Centered Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 flex flex-col items-center text-center space-y-6">
            

            {/* Requested: Horizontal 6-line layout with binary/dual markers - Scaled Up */}
            <h1 className="flex flex-col items-center gap-5 py-6">
              {[
                { text: <>پکت‌لاس نزدیک به <span className="font-mono text-sky-300 drop-shadow-[0_0_12px_rgba(56,189,248,0.9)] text-[1.2em] inline-block align-middle">{zeroVal}</span></>, color: 'text-sky-500/40', b1: '010110', b2: '110011' },
                { text: <>و آپ‌تایم <span className="font-mono text-sky-300 drop-shadow-[0_0_12px_rgba(56,189,248,0.9)] text-[1.2em] inline-block align-middle">{uptimeVal}</span></>, color: 'text-sky-500/40', b1: '101001', b2: '001100' },
                { text: <>پایداری <span className="text-emerald-300 drop-shadow-[0_0_10px_rgba(52,211,153,0.8)] text-[1.2em] inline-block align-middle">مطلق</span></>, color: 'text-emerald-500/40', b1: '010110', b2: '110011' },
                { text: <>حتی در</>, color: 'text-white/20', b1: '101001', b2: '001100' },
                { text: <><span className="text-rose-300 drop-shadow-[0_0_10px_rgba(251,113,133,0.8)] text-[1.2em] inline-block align-middle">شلوغ‌ترین</span></>, color: 'text-rose-500/40', b1: '010110', b2: '110011' },
                { text: <>ساعات شبکه</>, color: 'text-white/20', b1: '101001', b2: '001100' }
              ].map((line, idx) => (
                <BinaryText 
                  key={idx}
                  binaryClassName={line.color}
                  leftBinary={line.b1}
                  rightBinary={line.b2}
                  className="text-2xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-white"
                >
                  {line.text}
                </BinaryText>
              ))}
            </h1>





            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-20 w-full sm:w-auto">
              
              {/* View Plans Button */}
              <button
                id="hero-view-plans-cta"
                onClick={() => onScrollToSection('packages')}
                className="whitespace-nowrap flex-shrink-0 w-full sm:w-auto group relative px-7 py-3.5 rounded-2xl bg-gradient-to-r from-purple-600 via-pink-600 to-orange-500 hover:from-purple-500 hover:via-pink-500 hover:to-orange-400 text-white font-bold text-sm sm:text-base shadow-[0_10px_30px_rgba(236,72,153,0.4)] hover:scale-105 transition-all duration-300 flex items-center justify-center gap-2.5 text-center shine-effect"
              >
                <Layers className="w-5 h-5 text-sky-200 group-hover:rotate-12 transition duration-300" />
                <span>مشاهده پلن‌ها و شرایط</span>
                <ArrowLeft className="w-4 h-4 rtl:rotate-0 ltr:rotate-180 group-hover:-translate-x-1 transition duration-200" />
              </button>
            </div>



          </div>

          {/* Right Column: Simplified Elegant Visualizer Card */}
          <div className="lg:col-span-5 relative">
            
            {/* Glowing Backdrop Frame */}
            <div className="absolute -inset-1 bg-gradient-to-r from-orange-500/20 via-pink-500/20 to-purple-600/30 rounded-3xl blur-2xl opacity-80 animate-pulse"></div>

            <div className="relative rounded-3xl bg-slate-900/60 border border-white/10 p-6 sm:p-7 shadow-2xl backdrop-blur-2xl overflow-hidden space-y-5 text-center">
              
              {/* Header inside Card (Clean Persian) */}
              <div className="flex items-center justify-center border-b border-white/10 pb-4">
                <div className="flex items-center gap-2">
                  <div className="relative flex items-center justify-center w-3 h-3">
                    <div className="absolute w-6 h-6 bg-sky-400/40 rounded-full animate-ping"></div>
                    <div className="absolute w-4 h-4 bg-sky-400/60 rounded-full animate-pulse"></div>
                    <div className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-[0_0_12px_#38bdf8] relative z-10"></div>
                  </div>
                  <span className="text-xs font-bold text-slate-200">
                    روتینگ اختصاصی بین‌المللی
                  </span>
                </div>

              </div>

              {/* Smart Routing Hub & Spoke Architecture */}
              <div className="rounded-2xl bg-slate-950/80 border border-purple-500/30 p-3 shadow-xl space-y-3 text-right">


                {/* Top: European Servers */}
                <div className="space-y-1">

                  <div className="grid grid-cols-3 gap-2">
                    {euServers.map((server) => {
                      const minPing = Math.min(...euServers.map(x => x.ping));
                      const isOptimal = server.ping === minPing;
                      return (
                        <div
                          key={server.id}
                          className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center transition-all duration-300 relative ${
                            isOptimal 
                              ? 'bg-sky-500/20 border-sky-500/80 shadow-[0_0_15px_rgba(56,189,248,0.3)] text-white scale-[1.02]' 
                              : 'bg-white/5 border-white/10 text-slate-300'
                          }`}
                        >
                        <div className={`absolute -bottom-2.5 w-0.5 h-3 ${isOptimal ? 'bg-sky-400 shadow-[0_0_6px_#38bdf8] animate-pulse' : 'bg-white/10'}`}></div>
                        <span className="text-[11px] font-bold truncate w-full">{server.name}</span>
                          <span className={`font-mono font-bold text-[11px] mt-0.5 px-1.5 py-0.5 rounded ${
                            isOptimal ? 'bg-sky-500/30 text-sky-300 border border-sky-500/50' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {server.ping} ms
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Middle: Central Hub Node (Turkey Gateway) */}
                <div className="relative py-1">
                  {/* Vertical Connection Line - Hub Trunk */}
                  <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-gradient-to-b from-sky-500/50 via-purple-500/50 to-purple-400/50"></div>
                  
                  <div className="absolute inset-x-0 top-1/2 h-0.5 bg-gradient-to-r from-purple-500/20 via-sky-500/50 to-purple-500/25 -translate-y-1/2"></div>
                  
                  <div className="relative z-10 p-2.5 rounded-xl bg-gradient-to-r from-purple-900/50 via-indigo-950/90 to-purple-900/50 border border-purple-500/50 flex items-center justify-center gap-4 shadow-md text-center">
                    <div className="flex items-center gap-2.5">
                      <div className="relative flex items-center justify-center w-2.5 h-2.5">
                        <div className="absolute w-4 h-4 bg-purple-400/50 rounded-full animate-ping"></div>
                        <div className="w-2 h-2 rounded-full bg-purple-400 shadow-[0_0_8px_#c084fc] relative z-10"></div>
                      </div>
                      <span className="text-xs font-bold text-white">هاب مرکزی ترکیه</span>
                    </div>
                    <span className="text-[10px] font-mono font-bold text-sky-400 bg-sky-500/10 border border-sky-500/30 px-2 py-0.5 rounded min-w-[45px]">
                      {hubPing}ms
                    </span>
                  </div>
                </div>

                {/* Bottom: Iran Servers */}
                <div className="space-y-1">
                  <div className="grid grid-cols-3 gap-2">
                    {iranServers.map((server) => {
                      const minPing = Math.min(...iranServers.map(x => x.ping));
                      const isOptimal = server.ping === minPing;
                      return (
                        <div
                          key={server.id}
                          className={`p-2 rounded-xl border flex flex-col items-center justify-center text-center relative transition-all duration-300 ${
                            isOptimal 
                              ? 'bg-sky-500/20 border-sky-500/50 shadow-[0_0_15px_rgba(56,189,248,0.2)] text-white' 
                              : 'bg-white/5 border-white/10 text-slate-300'
                          }`}
                        >
                          <div className={`absolute -top-2.5 w-0.5 h-3 ${isOptimal ? 'bg-sky-400 shadow-[0_0_6px_#38bdf8] animate-pulse' : 'bg-purple-400/50'}`}></div>
                          <span className="text-[11px] font-bold truncate w-full">{server.name}</span>
                          <span className={`font-mono font-bold text-[11px] mt-0.5 px-1.5 py-0.5 rounded ${
                            isOptimal ? 'bg-sky-500/30 text-sky-300 border border-sky-500/50' : 'bg-slate-800 text-slate-300'
                          }`}>
                            {server.ping} ms
                          </span>
                          <div className={`absolute -bottom-3 w-0.5 h-3 ${isOptimal ? 'bg-sky-400 shadow-[0_0_6px_#38bdf8] animate-pulse' : 'bg-white/20'}`}></div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>



              {/* Simplified Service Performance Highlights */}
              <div className="space-y-3 text-xs text-center">
                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between gap-4 backdrop-blur-sm transition-all duration-300 hover:border-emerald-500/40 hover:bg-white/[0.07]">
                  <div className="flex items-center gap-2.5 flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-emerald-400 shadow-[0_0_8px_#34d399]"></div>
                    <span className="text-slate-200 font-bold">پینگ</span>
                  </div>
                  
                  <div className="hidden sm:flex flex-1 items-center mx-2">
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden shadow-inner">
                      <div className="w-[12%] h-full bg-emerald-500 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.5)]"></div>
                    </div>
                  </div>

                  <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-3 py-1.5 rounded-xl border border-emerald-500/20 flex-shrink-0 min-w-[75px] inline-flex justify-center" dir="ltr">
                    50 ms
                  </span>
                </div>

                <div className="p-3.5 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-between gap-4 backdrop-blur-sm transition-all duration-300 hover:border-purple-500/40 hover:bg-white/[0.07]">
                  <div className="flex items-center gap-2.5 flex-shrink-0">
                    <div className="w-2 h-2 rounded-full bg-purple-400 shadow-[0_0_8px_#a855f7]"></div>
                    <span className="text-slate-200 font-bold">پهنای باند</span>
                  </div>

                  <div className="hidden sm:flex flex-1 items-center mx-2">
                    <div className="w-full h-1.5 bg-white/10 rounded-full overflow-hidden shadow-inner">
                      <div className="w-full h-full bg-purple-500 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.5)]"></div>
                    </div>
                  </div>
                  
                  <span className="text-xs font-mono font-bold text-purple-400 bg-purple-500/10 px-3 py-1.5 rounded-xl border border-purple-500/20 flex-shrink-0 min-w-[75px] inline-flex justify-center" dir="ltr">
                    1 Gb/s
                  </span>
                </div>
              </div>

            </div>

          </div>

        </div>

        {/* Bottom Feature Metric Cards removed as requested */}

      </div>
    </section>
  );
};
