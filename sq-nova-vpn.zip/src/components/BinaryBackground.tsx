import React, { useEffect, useRef } from 'react';

export const BinaryBackground: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width: number;
    let height: number;
    let columns: number;
    let drops: number[];

    const fontSize = 14;
    const chars = ['0', '1'];

    const resize = () => {
      width = window.innerWidth;
      height = window.innerHeight;
      canvas.width = width;
      canvas.height = height;
      
      columns = Math.floor(width / fontSize);
      drops = new Array(columns).fill(1);
    };

    window.addEventListener('resize', resize);
    resize();

    const colors = [
      'rgba(56, 189, 248, ',  // sky-400
      'rgba(52, 211, 153, ',  // emerald-400
      'rgba(251, 113, 133, ', // rose-400
      'rgba(168, 85, 247, ', // purple-500
      'rgba(251, 191, 36, ',  // amber-400
    ];

    const draw = () => {
      // semi-transparent overlay to create trail
      ctx.fillStyle = 'rgba(2, 6, 23, 0.1)';
      ctx.fillRect(0, 0, width, height);

      ctx.font = `${fontSize}px monospace`;

      // 1. Traditional Matrix Rain with Random Colors
      for (let i = 0; i < drops.length; i++) {
        const text = chars[Math.floor(Math.random() * chars.length)];
        
        // Random color from the theme
        const colorBase = colors[Math.floor(Math.random() * colors.length)];
        const alpha = Math.random() * 0.3 + 0.1;
        
        // Sometimes draw a bright "head"
        if (Math.random() > 0.98) {
          ctx.fillStyle = '#fff';
          ctx.shadowBlur = 8;
          ctx.shadowColor = '#fff';
        } else {
          ctx.fillStyle = colorBase + alpha + ')';
          ctx.shadowBlur = 0;
        }

        ctx.fillText(text, i * fontSize, drops[i] * fontSize);

        if (drops[i] * fontSize > height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }

      // 2. Extra "Popping" Random Binary at Random Locations
      // This adds that "scattered" look requested
      for (let j = 0; j < 5; j++) {
        const rx = Math.random() * width;
        const ry = Math.random() * height;
        const rt = chars[Math.floor(Math.random() * chars.length)];
        const rc = colors[Math.floor(Math.random() * colors.length)];
        ctx.fillStyle = rc + (Math.random() * 0.2) + ')';
        ctx.fillText(rt, rx, ry);
      }

      animationFrameId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 w-full h-full -z-50 pointer-events-none opacity-40"
      style={{ background: '#020617' }}
    />
  );
};
